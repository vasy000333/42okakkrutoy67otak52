Set fso = CreateObject("Scripting.FileSystemObject")
scriptPath = WScript.ScriptFullName
dim r
Randomize
r = Rnd 
for i=1 to 2
   fso.CopyFile scriptPath, "РєРѕРїРёСЏСЃРѕСЃР°Р»1" & i & r & ".vbs", True
next
